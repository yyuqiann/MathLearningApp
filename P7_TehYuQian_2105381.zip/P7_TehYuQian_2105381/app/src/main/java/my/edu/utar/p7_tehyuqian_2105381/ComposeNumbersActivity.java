package my.edu.utar.p7_tehyuqian_2105381;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.view.View;
import android.view.animation.AlphaAnimation;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import java.util.Random;

public class ComposeNumbersActivity extends AppCompatActivity {
    private TextView targetNumber, result;
    private EditText input1, input2;
    private Button nextQuestion;
    private int target;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_compose_numbers);

        targetNumber = findViewById(R.id.targetNumber);
        input1 = findViewById(R.id.input1);
        input2 = findViewById(R.id.input2);
        Button checkAddBtn = findViewById(R.id.checkAddBtn);
        Button checkSubBtn = findViewById(R.id.checkSubBtn);
        nextQuestion = findViewById(R.id.nextQuestion);
        result = findViewById(R.id.result);

        checkAddBtn.setOnClickListener(this::checkAddition);
        checkSubBtn.setOnClickListener(this::checkSubtraction);
        nextQuestion.setOnClickListener(this::nextQuestion);

        generateTargetNumber();
    }

    private void generateTargetNumber() {
        Random rand = new Random();
        target = rand.nextInt(20) + 1;
        targetNumber.setText(String.valueOf(target));
        result.setText("");
        input1.setText(""); // Clear previous input
        input2.setText(""); // Clear previous input
        nextQuestion.setVisibility(View.GONE);
    }

    @SuppressLint("SetTextI18n")
    public void checkAddition(View view) {
        if (validateInput()) {
            int num1 = Integer.parseInt(input1.getText().toString());
            int num2 = Integer.parseInt(input2.getText().toString());
            if (num1 + num2 == target) {
                result.setText("🎉 Correct! 🎉");
                nextQuestion.setVisibility(View.VISIBLE);
            } else {
                result.setText("❌ Try Again!");
            }
        }
    }

    @SuppressLint("SetTextI18n")
    public void checkSubtraction(View view) {
        if (validateInput()) {
            int num1 = Integer.parseInt(input1.getText().toString());
            int num2 = Integer.parseInt(input2.getText().toString());
            if (num1 - num2 == target) {
                result.setText("🎉 Correct! 🎉");
                nextQuestion.setVisibility(View.VISIBLE);
            } else {
                result.setText("❌ Try Again!");
            }
        }
    }

    private boolean validateInput() {
        if (input1.getText().toString().isEmpty() || input2.getText().toString().isEmpty()) {
            Toast.makeText(this, "Please enter both numbers", Toast.LENGTH_SHORT).show();
            return false;
        }
        return true;
    }

    public void nextQuestion(View view) {
        generateTargetNumber();
    }
}
