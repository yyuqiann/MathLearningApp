package my.edu.utar.p7_tehyuqian_2105381;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.view.View;
import android.view.animation.AlphaAnimation;
import android.widget.Button;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Random;

public class OrderNumbersActivity extends AppCompatActivity {
    private TextView numbersDisplay, result;
    private Button option1, option2, option3, option4, nextQuestion;
    private Integer[] numbers, correctSortedNumbers;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_order_numbers);

        numbersDisplay = findViewById(R.id.numbersDisplay);
        result = findViewById(R.id.result);
        option1 = findViewById(R.id.option1);
        option2 = findViewById(R.id.option2);
        option3 = findViewById(R.id.option3);
        option4 = findViewById(R.id.option4);
        nextQuestion = findViewById(R.id.nextQuestion);

        generateNumbers();
    }

    @SuppressLint("SetTextI18n")
    private void generateNumbers() {
        Random rand = new Random();
        numbers = new Integer[]{rand.nextInt(100), rand.nextInt(100),
                rand.nextInt(100), rand.nextInt(100)};
        boolean isAscending = rand.nextBoolean();
        numbersDisplay.setText("Order: " + (isAscending ? "Ascending" : "Descending")
                + "\n" + Arrays.toString(numbers));
        result.setText("");
        nextQuestion.setVisibility(View.GONE);

        correctSortedNumbers = numbers.clone();
        if (isAscending) {
            Arrays.sort(correctSortedNumbers);
        } else {
            Arrays.sort(correctSortedNumbers, Collections.reverseOrder());
        }
        setRandomOptions();
    }

    private void setRandomOptions() {
        List<String> options = new ArrayList<>();
        options.add(Arrays.toString(correctSortedNumbers));

        while (options.size() < 4) {
            Integer[] shuffled = numbers.clone();
            List<Integer> shuffledList = Arrays.asList(shuffled);
            Collections.shuffle(shuffledList);
            shuffledList.toArray(shuffled);

            if (!options.contains(Arrays.toString(shuffled))) {
                options.add(Arrays.toString(shuffled));
            }
        }

        Collections.shuffle(options);

        option1.setText(options.get(0));
        option2.setText(options.get(1));
        option3.setText(options.get(2));
        option4.setText(options.get(3));
    }

    @SuppressLint("SetTextI18n")
    public void checkAnswer(View view) {
        Button clickedButton = (Button) view;
        if (clickedButton.getText().toString().equals(Arrays.toString(correctSortedNumbers))) {
            result.setText("🎉 Correct! 🎉");
            result.setTextColor(getResources().getColor(android.R.color.holo_green_dark));
            AlphaAnimation fadeIn = new AlphaAnimation(0.0f, 1.0f);
            fadeIn.setDuration(500);
            result.startAnimation(fadeIn);
            nextQuestion.setVisibility(View.VISIBLE);
        } else {
            result.setText("❌ Try Again!");
            result.setTextColor(getResources().getColor(android.R.color.holo_red_dark));
        }
    }


    public void nextQuestion(View view) {
        generateNumbers();
    }
}