package my.edu.utar.p7_tehyuqian_2105381;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import java.util.Random;

public class CompareNumbersActivity extends AppCompatActivity {
    private TextView number1Display, number2Display, result;
    private Button nextQuestion;
    private int number1, number2;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_compare_numbers);

        number1Display = findViewById(R.id.number1Display);
        number2Display = findViewById(R.id.number2Display);
        result = findViewById(R.id.result);
        Button greaterBtn = findViewById(R.id.greaterBtn);
        Button lesserBtn = findViewById(R.id.lesserBtn);
        Button equalBtn = findViewById(R.id.equalBtn);
        nextQuestion = findViewById(R.id.nextQuestion);

        generateNumbers();

        greaterBtn.setOnClickListener(this::checkAnswer);
        lesserBtn.setOnClickListener(this::checkAnswer);
        equalBtn.setOnClickListener(this::checkAnswer);
        nextQuestion.setOnClickListener(this::nextQuestion);
    }

    private void generateNumbers() {
        Random rand = new Random();
        number1 = rand.nextInt(100);
        number2 = rand.nextInt(100);

        number1Display.setText(String.valueOf(number1));
        number2Display.setText(String.valueOf(number2));
        result.setText("");
        nextQuestion.setVisibility(View.GONE);
    }

    @SuppressLint("SetTextI18n")
    public void checkAnswer(View view) {
        Button clickedButton = (Button) view;
        String answer = clickedButton.getText().toString();

        if ((answer.equals("Greater than") && number1 > number2) ||
                (answer.equals("Less than") && number1 < number2) ||
                (answer.equals("=") && number1 == number2)) {
            result.setText("🎉 Correct! 🎉");
            result.setTextColor(getResources().getColor(android.R.color.holo_green_dark));
            nextQuestion.setVisibility(View.VISIBLE);
        } else {
            result.setText("❌ Try Again!");
            result.setTextColor(getResources().getColor(android.R.color.holo_red_dark));
        }
    }


    public void nextQuestion(View view) {
        generateNumbers();
    }
}


